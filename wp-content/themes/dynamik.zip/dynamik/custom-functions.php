<?php
/* Put Any Custom PHP Functions For Your WordPress Site In This File */

//end custom-functions.php