<?php
/**
 * A deprecated file that is required for Dynamik 1.0 compatibility.
 *
 * @package Catalyst
 */

//end lib/functions/catalyst-dynamik-styles.php