<?php
/**
 * Requires (pulls in) the initializing functions of Catalyst
 * which are found in the catalyse.php file.
 *
 * @package Catalyst
 */
 
/**
 * Pull in the catalyse.php content.
 */
require_once( get_template_directory() . '/lib/catalyse.php' );

//end functions.php