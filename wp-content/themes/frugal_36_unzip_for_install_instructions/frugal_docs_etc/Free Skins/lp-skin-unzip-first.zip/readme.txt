******************************************************
*** LP Skin for the Frugal Premium Wordpress Theme ***
******************************************************

The Frugal LP (Landing Page) Skin is a Free Skin for the Frugal Theme that provides a fast and easy

way to create Wordpress Landing and Sales pages.  You must first have the Frugal Theme installed

before you can Import any Frugal Skins.  You can reference the following instructions if necessary:

http://skins.frugaltheme.com/how-to-install-a-skin/

NOTE: When installing the LP Skin you will be using the lp-skin.zip file inside this folder.


Getting Started:

Once you've successfully Imported the LP Skin into Frugal there are just a few things you need to do

to finish setting up the Landing Page.

1: The first thing you need to do is remove the Navbar (assuming you want it removed).  To do this

you need to go to the 'Main Options' Frugal options page and find the option box titled:

"Page/Category Display Control"

Inside this option box you will find a Textarea titled "Remove Specific Page Items".  Paste the

following code inside this Textarea: #navbar_wrap

and then click the Save button on that options page.  This should remove your Navbar.

2: Next you need to select which page you want to Feature on your homepage (create this page in

Wordpress if you haven't already).  To do this you need to go to the 'Feature Options' Frugl options

page and find the option box titled:

"Home Top Featured Content"

Inside this option box you will find a drop-down menu titled "Page To Display".  Select your page

from this menu and then click the Save button on that options page.  This should display your chosen

page on your homepage.

3: Finally, you just need to be aware that the right side of your homepage will have a blank space

(unless you have a widget in the Home Sidebar widget area).  This is the Home Sidebar widget location

and you will add content here by going to the Wordpress Widgets (Appearance > Widgets) and adding

widget content to the "Home Sidebar" widget area.


For more information on the many available Widgets in Frugal you can go here:

http://support.frugaltheme.com/index.php?articleId=7&categoryId=3&pageId=3


Enjoy!

The Frugal Team