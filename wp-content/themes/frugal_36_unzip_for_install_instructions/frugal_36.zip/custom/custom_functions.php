<?php

// Use this file to define custom functions and then hook them into the desired location
// in the theme.  Learn more about this customization process by visiting
/* http://frugaltheme.com/support/ */